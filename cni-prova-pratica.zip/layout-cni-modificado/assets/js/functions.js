function exibeTxtEsfera(idEle, idtxt){
    let eleBola = document.getElementById(idEle);
    let eleTexto = document.getElementById(idtxt);
    eleBola.classList.add("esfera-color");

    eleTexto.classList.remove("txt-esfera-out");
    eleTexto.classList.add("txt-esfera-in");
}

var objSlide = [
    {"img":"Ícone 1.png","descricao":"Teoria Conectivista: o professor busca <br>possibilitar que seus alunos tomem decisões <br>diante do que aprender, quando aprender e <br>onde buscar conhecimento, especialmente, <br>através de tecnologias digitais."},
    {"img":"Ícone 2.png","descricao":"Teoria Cognitivista: o professor <br>trabalha com a estruturação <br>do conhecimento para a <br>aprendizagem, preocupando-se em <br>ensinar a aprender."},
    {"img":"Ícone 3.png","descricao":"Teoria Socioconstrutivista: o professor <br>procura estabelecer comunidades de prática com <br>interação deliberada entre as pessoas que <br>aprendem, ou seja, promovem a <br>socialização."},
    {"img":"Ícone 4.png","descricao":"Teoria Humanista: <br>cabe ao professor <br>facilitar e mediar <br>o desenvolvimento <br>holístico."},
    {"img":"Ícone 5.png","descricao":"Teoria Conectivista: o professor busca <br>possibilitar que seus alunos tomem decisões diante<br> do que aprender, quando aprender e onde <br>buscar conhecimento, especialmente, <br>através de tecnologias digitais."}
]

function renderizaImgSlide(nomeImagem){
    let img = "<img src=\"assets/img/"+nomeImagem+"\">";
    var divIdImg = document.getElementById('img-slide');
    divIdImg.innerHTML = img;
}

function renderizaDescSlide(descricao){    
    var divIdTxt = document.getElementById('txt-slide');
    divIdTxt.innerHTML = descricao;
}

function renderSlide(pos, tam){
    if (pos >= 0 && pos < tam){
        renderizaImgSlide(objSlide[pos].img);
        renderizaDescSlide(objSlide[pos].descricao);
        sessionStorage.setItem('posicao', pos);
        if(pos == 0){
            document.getElementById('arrow-prev').innerHTML = "<img src=\"assets/img/Seta esquerda inativa.png\">";
        } else {
            document.getElementById('arrow-prev').innerHTML = "<img src=\"assets/img/Seta esquerda.png\">";
        }

        if(pos == 4){
            document.getElementById('arrow-next').innerHTML = "<img src=\"assets/img/Seta direita inativa.png\">";
        } else {
            document.getElementById('arrow-next').innerHTML = "<img src=\"assets/img/Seta direita.png\">";
        }
    }
}

var posicao = 0;
sessionStorage.setItem('posicao', posicao);

function passaSlide(opc){  
    let pos = parseInt(sessionStorage.getItem('posicao'));
    let tamArr = objSlide.length;  

    if(pos < tamArr && pos >= 0){
        if(opc == "1"){                
            pos--;    
            document.getElementById("img-slide").classList.remove("slideIn");
            document.getElementById("img-slide").classList.add("slideOut");
            setTimeout(function(){
                document.getElementById("img-slide").classList.remove("slideOut");
            },1000);
        } else if(opc == "2"){                
            pos++;       
            document.getElementById("img-slide").classList.remove("slideOut");
            document.getElementById("img-slide").classList.add("slideIn"); 
            setTimeout(function(){
                document.getElementById("img-slide").classList.remove("slideIn");
            },1000);             
        } else {
            document.getElementById("img-slide").classList.remove("slideOut");
            document.getElementById("img-slide").classList.add("slideIn");
            setTimeout(function(){
                document.getElementById("img-slide").classList.remove("slideIn");
            },1000);
        }

        switch(pos){
            case 0:               
                document.getElementById("nav1").classList.add("nav-slide-ativo");
                document.getElementById("nav2").classList.add("nav-slide-inativo");
                document.getElementById("nav3").classList.add("nav-slide-inativo");
                document.getElementById("nav4").classList.add("nav-slide-inativo");
                document.getElementById("nav5").classList.add("nav-slide-inativo");                
            break;
            case 1:                 
                document.getElementById("nav2").classList.remove("nav-slide-inativo");
                document.getElementById("nav2").classList.add("nav-slide-ativo");
                document.getElementById("nav3").classList.add("nav-slide-inativo");
                document.getElementById("nav4").classList.add("nav-slide-inativo");
                document.getElementById("nav5").classList.add("nav-slide-inativo");
            break;
            case 2: 
                document.getElementById("nav3").classList.remove("nav-slide-inativo");
                document.getElementById("nav3").classList.add("nav-slide-ativo");
                document.getElementById("nav4").classList.add("nav-slide-inativo");
                document.getElementById("nav5").classList.add("nav-slide-inativo");
            break;
            case 3: 
                document.getElementById("nav4").classList.remove("nav-slide-inativo");
                document.getElementById("nav4").classList.add("nav-slide-ativo");
                document.getElementById("nav5").classList.add("nav-slide-inativo");
            break;
            case 4: 
                document.getElementById("nav5").classList.remove("nav-slide-inativo");
                document.getElementById("nav5").classList.add("nav-slide-ativo");
            break;
        }              
    } 

    renderSlide(pos,tamArr);
    
}